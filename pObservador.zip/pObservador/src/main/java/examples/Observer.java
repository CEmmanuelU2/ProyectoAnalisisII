package examples;

public interface Observer {
    void update(double temperature);
}