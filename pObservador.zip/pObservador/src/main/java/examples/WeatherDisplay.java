package examples;
@AllArgsConstructor
public class WeatherDisplay implements Observer {
    private String name;

    @Override
    public void update(double temperature) {
        System.out.println(name + " muestra la temperatura actual: " + temperature);
    }
}