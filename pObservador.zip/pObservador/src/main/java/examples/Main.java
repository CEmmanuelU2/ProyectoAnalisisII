package examples;

public class Main {
    public class Main {
        public static void main(String[] args) {
            WeatherStation station = new WeatherStation();
            WeatherDisplay display1 = new WeatherDisplay("Pantalla 1");
            WeatherDisplay display2 = new WeatherDisplay("Pantalla 2");

            station.addObserver(display1);
            station.addObserver(display2);

            station.setTemperature(25.5);
        }
    }
}
